 
    
    <div id="primaryWrapper">
    	<div id="primaryContent">
        	
            <h1>Thanks for your message</h1>
            
            <div class="contactForm">
            	
                <h2>We&rsquo;ll get back to you as soon as we can...</h2>
                
                
                
            
            </div>
            
            <div class="contactDetails">
            	<h3>Contact details</h3>
                <p><span>e</span> <a href="mailto:">enquiries@iode.co.uk</a></p>
                <p><span>t</span> 0772 586 8647</p>
            </div>
            
        </div>
    </div>
    
    
    
