<?php

// SET SOME VARIABLES FOR THE PAGE TO USE

$html_title = "About Iode Software";
$html_keywords = "iphone developer, android developer, nokia developer, mobile development, mobile applications, iphone apps, android apps, nokia apps, mobile software";
$html_description = "";
$html_section = "about";
$html_page = "";

include ('includes/header.php');
include ('includes/content-about.php');
include ('includes/footer.php');

?>
