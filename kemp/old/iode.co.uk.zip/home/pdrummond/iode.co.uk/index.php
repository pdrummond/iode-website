<?php

// SET SOME VARIABLES FOR THE PAGE TO USE

$html_title = "Iode Software";
$html_keywords = "iphone developer, android developer, nokia developer, mobile development, mobile applications, iphone apps, android apps, nokia apps, mobile software";
$html_description = "Home of Iode Software";
$html_section = "home";
$html_page = "";

include ('includes/header.php');
include ('includes/content-home.php');
include ('includes/footer.php');

?>
