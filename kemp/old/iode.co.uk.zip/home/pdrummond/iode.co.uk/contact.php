<?php


// INCLUDE FORM PROCESSOR

include ('includes/process-contact.php');


// SET SOME VARIABLES FOR THE PAGE TO USE

$html_title = "Contact Iode Software";
$html_keywords = "iphone developer, android developer, nokia developer, mobile development, mobile applications, iphone apps, android apps, nokia apps, mobile software";
$html_description = "";
$html_section = "contact";
$html_page = "";

include ('includes/header.php');
include ('includes/content-contact.php');
include ('includes/footer.php');

?>
