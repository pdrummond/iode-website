<?php

// SET SOME VARIABLES FOR THE PAGE TO USE

$html_title = "Iode Software Services";
$html_keywords = "iphone developer, android developer, nokia developer, mobile development, mobile applications, iphone apps, android apps, nokia apps, mobile software";
$html_description = "";
$html_section = "services";
$html_page = "";

include ('includes/header.php');
include ('includes/content-services.php');
include ('includes/footer.php');

?>
